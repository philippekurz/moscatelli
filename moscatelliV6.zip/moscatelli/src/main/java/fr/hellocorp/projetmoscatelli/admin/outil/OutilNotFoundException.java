package fr.hellocorp.projetmoscatelli.admin.outil;

public class OutilNotFoundException extends Throwable {
    public OutilNotFoundException(String message) {super(message);}
}
