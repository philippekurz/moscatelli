package fr.hellocorp.projetmoscatelli.admin.entree_sortie;

public class EntreeSortieNotFoundException extends Exception {
    public EntreeSortieNotFoundException(String message) {super(message);}
}
