package fr.hellocorp.projetmoscatelli.admin.utilisateur;

public class UtilisateurNotFoundException extends Throwable{
    public UtilisateurNotFoundException (String message) {super(message);}
}
